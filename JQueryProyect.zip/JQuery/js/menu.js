navBar.innerHTML +=

`
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="container-fluid">
  <a class="navbar-brand" href="index.html">Proyecto JQ </a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Módulos  
        </a>
        <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="Estudiantes.html">Estudiante</a></li>
        <li><a class="dropdown-item" href="Profesores.html">Profesor</a></li>
        <li><a class="dropdown-item" href="Grupo.html">Grupo</a></li>
        <li><a class="dropdown-item" href="Curso.html">Curso</a></li>
        </ul>
    </li>
        <a class="nav-link" href="https://paginas-web-cr.com/ApiPHP/" target="_blank">API</a>
    </div>
  </div>
</div>
</nav>
`