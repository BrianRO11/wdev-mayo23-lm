import { CursoResponse } from './curso-response';

describe('CursoResponse', () => {
  it('should create an instance', () => {
    expect(new CursoResponse()).toBeTruthy();
  });
});
