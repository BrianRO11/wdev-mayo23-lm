import { Curso } from "./curso";

export class CursoResponse {
    code: number = 0;
    message: string = '';
    data: Curso []=[];
}
