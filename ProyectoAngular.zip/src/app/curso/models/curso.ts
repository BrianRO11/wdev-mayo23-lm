export class Curso {
    id: string= "";
    nombre: string= "";
    descripcion: string= "";
    tiempo: string= "";
    usuario: string= "";
}
