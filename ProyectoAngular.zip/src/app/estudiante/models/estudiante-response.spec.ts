import { EstudianteResponse } from './estudiante-response';

describe('EstudianteResponse', () => {
  it('should create an instance', () => {
    expect(new EstudianteResponse()).toBeTruthy();
  });
});
