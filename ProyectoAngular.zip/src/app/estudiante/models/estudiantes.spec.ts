import { Estudiantes } from './estudiantes';

describe('Estudiantes', () => {
  it('should create an instance', () => {
    expect(new Estudiantes()).toBeTruthy();
  });
});
