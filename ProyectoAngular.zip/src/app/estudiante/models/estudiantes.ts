export class Estudiantes {
    id: string= "";
    cedula: string= "";
    correoelectronico: string= "";
    telefono: string= "";
    telefonocelular: string= "";
    fechanacimiento: string= "";
    sexo: string= "";
    direccion: string= "";
    nombre: string= "";
    apellidopaterno: string= "";
    apellidomaterno: string= "";
    nacionalidad: string= "";
    idCarreras: string= "";
    usuario: string= "";

}
// <!-- //{"id":"","cedula":"","correoelectronico":
//   ,"telefono":,"telefonocelular":,"fechanacimiento":,"sexo":,"direccion":
//   ","nombre":,"apellidopaterno":,"apellidomaterno":","nacionalidad"
//   :,"idCarreras":,"usuario"} -->