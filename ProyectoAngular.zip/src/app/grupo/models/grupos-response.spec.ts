import { GruposResponse } from './grupos-response';

describe('GruposResponse', () => {
  it('should create an instance', () => {
    expect(new GruposResponse()).toBeTruthy();
  });
});
