import { Grupos } from './grupos';

describe('Grupos', () => {
  it('should create an instance', () => {
    expect(new Grupos()).toBeTruthy();
  });
});
