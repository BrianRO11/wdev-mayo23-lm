import { RespuestaCursos } from './respuesta-cursos';

describe('RespuestaCursos', () => {
  it('should create an instance', () => {
    expect(new RespuestaCursos()).toBeTruthy();
  });
});
