import { Cursos } from "./cursos";

export class RespuestaCursos {
    code: number = 0;
    message: string = '';
    data: Cursos []=[];
}
