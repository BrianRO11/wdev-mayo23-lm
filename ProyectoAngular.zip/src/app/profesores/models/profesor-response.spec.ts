import { ProfesorResponse } from './profesor-response';

describe('ProfesorResponse', () => {
  it('should create an instance', () => {
    expect(new ProfesorResponse()).toBeTruthy();
  });
});
