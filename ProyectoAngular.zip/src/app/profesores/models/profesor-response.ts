import { Profesor } from "./profesor";

export class ProfesorResponse {
    code: number = 0;
    message: string = '';
    data: Profesor []=[];
}
