import { Profesor } from './profesor';

describe('Profesor', () => {
  it('should create an instance', () => {
    expect(new Profesor()).toBeTruthy();
  });
});
