import { UsuarioResponse } from './usuario-response';

describe('UsuarioResponse', () => {
  it('should create an instance', () => {
    expect(new UsuarioResponse()).toBeTruthy();
  });
});
