export class Usuario {
    id: string= "";
    name: string= "";
    password: string= "";
    email: string= "";
    
}
