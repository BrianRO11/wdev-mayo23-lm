import logo from './logo.svg';
import './App.css';
import CambiarContrasena from './CambiarContrasena';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <CambiarContrasena></CambiarContrasena>
      </header>
    </div>
  );
}

export default App;
