import React, { useState } from "react";
import './General.css';

function CambiarContrasena(){        
        const [contrasena1, setContrasena1] = useState("");
        const [contrasena2, setContrasena2] = useState("");
        const [input1, setInput1] = useState("rojo");

        const clave1 = (e) => {
            setContrasena1(e.target.value);
            if(contrasena1.length < 9){
                setInput1("rojo");
            }
            else if (contrasena1.length > 9 && contrasena1.length < 12 ){
                setInput1("amarillo");
            }
            else if(contrasena1.length > 12){
                setInput1("verde");
            }
        };
        const clave2 = (e) => {setContrasena2(e.target.value) };

        const ValidarDatos = () => {
            if (contrasena1.length < 10 ){
                setInput1(true);
            }

            if (contrasena1 === contrasena2) {
                    alert("Cambio de contraseña exitoso");
            }
            else{
                alert("Las contraseñas no coinciden");
            }
        }

    return(
        <div className="login">
            <h1>Cambiar Contraseña</h1>
            <h4 className={input1}>Nivel de seguridad</h4>
            <h5 className="nivelRojo">Rojo = Debil</h5>
            <h5 className="nivelAmarillo">Amarillo = Medio</h5>
            <h5 className="nivelVerde">Verde = Fuerte</h5>
            <div className="input1">
                <input id="input1" value={contrasena1} onChange={clave1} type="" className= {input1} placeholder="Ingresar contraseña"></input>
            </div> 
            <diV className="input2">
                <input value={contrasena2} onChange={clave2} type="" className="" placeholder="Confirmar contraseña"></input>
            </diV>            
            <br></br>
            <button onClick={ValidarDatos} className="Validar">Validar contraseñas</button>

        </div>
    );
}

export default CambiarContrasena;

/*
Si la contrasena tiene menos de 10 caracteres entonces color rojo.
Si la contrasena tiene enre 11 y 13 caracteres, entonces color amarillo.
Si la contrasena tiene mas de 14 caracteres, entonces usted coloquele color verde.

Tiene que validar que ambas contrasenas sean iguales

onClick para validar con las contrasenas, la nueva y la confirmacion.
onInput para validar la seguridad de la contrasena.

Opcional: Que tenga al menos un caracter especial /*.!#%&

*/